var betterTiming = [];

betterTiming.weather = {
	sunny: "Sunny", 
	mostly_sunny: "Mostly Sunny", 
	cloudy: "Cloudy",
	partly_cloudy: "Partly Cloudy",
	clear_day: "Clear",
	clear_night: "Clear - Night",
	rain: "Rain",
	sleet: "Sleet",
	snow: "Snow"
}

/*
betterTiming.fields = {
   "params":{ 
	  "eventName":"87\u00ba Edition des 24 Heures du Mans",
	  "sessionId":1438,
	  "timestamp":"1560457622000",
	  "elapsedTime":"27:02",
	  "racestate":"green",
	  "safetycar":"false",
	  "weather":"mostly_sunny",
	  "airTemp":"17.1",
	  "trackTemp":"22.8",
	  "humidity":63,
	  "pressure":1004.7,
	  "windSpeed":2.1,
	  "windDirection":64,
	  "elapsed":1622,
	  "remaining":5578,
	  "svg":"\/bundles\/fiaweclive\/svg\/lemans.svg"
   },
   "entries":[ 
	  { 
		 "ranking":1,
		 "number":7,
		 "id":35350,
		 "driver_id":215,
		 "state":"Run",
		 "isWEC":false,
		 "category":"LMP1",
		 "nationality":"JPN",
		 "team":"Toyota Gazoo Racing",
		 "tyre":"M",
		 "driver":"CONWAY M.",
		 "car":"Toyota TS050 - Hybrid",
		 "lap":"6",
		 "gap":"",
		 "gapPrev":"",
		 "classGap":"",
		 "classGapPrev":"",
		 "lastlap":"3:21.412",
		 "lastLapDiff":"-0.759",
		 "pitstop":1,
		 "bestlap":"3:15.497",
		 "speed":"243.5",
		 "bestSector1":"31.345",
		 "bestSector2":"1:14.897",
		 "bestSector3":"1:31.559",
		 "currentSector1":"33.054",
		 "currentSector2":"1:17.456",
		 "currentSector3":"",
		 "sector":3,
		 "lastPassingTime":"1560457590949",
		 "categoryPosition":1,
		 "position":{ 
			"percent":1,
			"sector":3,
			"timestamp":"1560457622000"
		 }
	  }
   ],
   "driversResult":[ 
	  { 
		 "driverID":215,
		 "laps":3,
		 "bestLap":"3:21.412",
		 "lastLap":"3:21.412",
		 "drivingTime":818,
		 "percentDriving":0,
		 "bestLapNumber":6,
		 "lastLapDiff":"-0.759",
		 "pitstop":0
	  }
   ]
}
*/

betterTiming.mapData = [
	{
		host: "scoring.imsa.com",
		dataPoints: {
			"S":"params.EventName",
			"TT": "params.elasped",
			"TR": "params.remaining",
			"F": "params.racestate",
			"SC": "params.safetycar", // 1 = SC deployed, else 0
			"B": "entries",
			"entries": {
				"A": "ranking",
				"C": "category",
				"N": "number",
				"PIC": "categoryPosition",
				"P": "state", // 1 = in pits, else 0
				"F": "driver",
				"V": "car",
				"L": "lap",
				"D": "gap",
				"G": "gapPrev",
				"DIC": "classgapPrev",
				"GIC": "classGap",
				"LL": "lastlap",
				"BL": "bestlap",
				"PS": "pitstop"
			}
		},
		values: {
			"entries.state": {
				0: "",
				1: "Pit"
			}
		}
	}
];

betterTiming.isUpdate = false;
betterTiming.countdown;
betterTiming.countdownTimer;
betterTiming.lapsRemaining = 599;
betterTiming.bestLap = "59:99.999";
betterTiming.bestSector1 = "59:99.999";
betterTiming.bestSector2 = "59:99.999";
betterTiming.bestSector3 = "59:99.999";
betterTiming.bestSpeed = 0;

betterTiming.$injectionPoint = $('body');
betterTiming.$wrapper = document.createElement('section');
betterTiming.$wrapper.classList = "enhanced-wrapper compact";

betterTiming.$statusTable = document.createElement('table');
betterTiming.$statusTable.classList = "enhanced-status";
betterTiming.$statusTable.innerHTML = '<thead></thead><tbody>' +
	'<tr class="row">' +
		'<td class="elapsed" style="display: none;" data-status="elapsed"></td>' +
		'<td class="remaining" data-status="remaining"></td>' +
		'<td class="status" data-status="racestate"></td>' +
		'<td class="weather" data-status="weather"></td>' +
	'</tr>';
				
betterTiming.$standingsTable = document.createElement('table');
betterTiming.$standingsTable.classList = "enhanced-order sortable";
betterTiming.$standingsTable.innerHTML = '<thead>' +
		'<tr class="row">' +
			'<th data-sort-method="number" data-sort-default>Pos</th>' +
			'<th>Num</th>' +
			'<th>PIC</th>' +
			'<th>Status</th>' +
			'<th class="align-left">Driver / Team / Car (Tire)</th>' +
			'<th>Laps</th>' +
			'<th class="hide-900">Best</th>' +
			'<th>Gap</th>' +
			'<th class="hide-900">Int</th>' +
			'<th>Lap Time</th>' +
			'<th class="hide-700" data-sector-header>S1</th>' +
			'<th class="hide-700" data-sector-header>S2</th>' +
			'<th class="hide-700" data-sector-header>S3</th>' +
			'<th class="car-speed" data-speed-header>Speed</th>' +
			'<th class="hide-700">Pit</th>' +
		'</tr>' +
	'</thead>' +
	'<tbody>' +
		'<tr data-template="car-row" :class="team.category">' +
			'<td class="car-ranking" data-entry="ranking"></td>' +
			'<td class="car-number" :class="team.category" data-entry="number"></td>' +
			'<td class="car-pic" :class="team.category" data-entry="categoryPosition"></td>' +
			'<td class="car-state" data-entry="state"></td>' +
			'<td class="car-team align-left">' +
				'<span class="car-detail-wrap">' +
					'<span class="driver" data-entry="driver"></span>' +
					'<span :class="team.category" data-entry="team"></span>' +
				'</span>' +
				'<span class="car-detail-wrap expanded-info justify-between">' +
					'<span class="driver-detail">' +
						'<span data-entry="driver_id"></span>' +
						'<span class="driver-detail-popup"></span>' +
					'</span>' +
					'<span class="car-car" data-entry="car"></span>' +
					'<span class="car-tire" data-entry="tyre"></span>' +
				'</span>' +
			'</td>' +
			'<td class="car-lap-count" data-entry="lap"></td>' +
			'<td class="car-bestlap hide-900" data-entry="bestlap"></td>' +
			'<td class="car-gaps">' +
				'<span data-entry="gap"></span>' +
				'<span class="previous expanded-info" data-entry="classGap"></span>' +
			'</td>' +
			'<td class="car-gap-previous hide-900">' +
				'<span data-entry="gapPrev"></span>' +
				'<span class="previous expanded-info" data-entry="classGapPrev"></span>' +
			'</td>' +
			'<td class="car-lap-times">' +
				'<span data-entry="lastlap"></span>' +
				'<span class="best expanded-info" data-entry="bestlap"></span>' +
			'</td>' +
			'<td class="sector hide-700" data-sector="1">' +
				'<span class="bar"></span>' +
				'<span class="current" data-entry="currentSector1"></span>' +
				'<span class="best expanded-info" data-entry="bestSector1"></span>' +
			'</td>' +
			'<td class="sector hide-700" data-sector="2">' +
				'<span class="bar"></span>' +
				'<span class="current" data-entry="currentSector2"></span>' +
				'<span class="best expanded-info" data-entry="bestSector2"></span>' +
			'</td>' +
			'<td class="sector hide-700" data-sector="3">' +
				'<span class="bar"></span>' +
				'<span class="current" data-entry="currentSector3"></span>' +
				'<span class="best expanded-info" data-entry="bestSector3"></span>' +
			'</td>' +
			'<td class="car-speed" data-speed>' +
				'<span data-entry="speed"></span>' +
			'</td>' +
			'<td class="car-pitstops hide-700">' +
				'<span data-entry="pitstop"></span>' +
				'<span class="expanded-info">' +
					'<span class="remaining" data-calc="pit-remaining"></span>' +
					'<span class="estimate" data-calc="pit-estimate"></span>' +
				'</span>' +
			'</td>' +
		'</tr>' + 
	'</tbody>';

// apply enhanced view
function enhance() {
	var fontLoadLink = document.createElement('link');
	fontLoadLink.href = 'https://fonts.googleapis.com/css?family=Source+Sans+Pro&display=swap';
	fontLoadLink.rel = 'stylesheet';
	document.head.prepend(fontLoadLink);

	$('body').addClass('enhanced');
	document.body.appendChild(betterTiming.$wrapper);
	$(betterTiming.$wrapper).append('<a id="betterTimingClose" href="#">Toggle</a>');
	betterTiming.$wrapper.appendChild(betterTiming.$statusTable);
	betterTiming.$wrapper.appendChild(betterTiming.$standingsTable);
	
	$('#betterTimingClose').on('click', function() {
		$('body').toggleClass('enhanced');
	});
	
	betterTiming.$data = document.querySelector('#__interceptedData');
	if (betterTiming.$data) {
		var betterTimingObserver = new MutationObserver(function(mutations, observer) {
			if (betterTiming.$data.textContent !== "") {
				//console.log(JSON.parse(betterTiming.$data.textContent));
				updateData(betterTiming.$data.textContent);
			}
		});
		
		betterTimingObserver.observe(betterTiming.$data, {
			attributes: true,
			characterData: true,
			childList: true,
			subtree: true,
			attributeOldValue: true,
			characterDataOldValue: true
		});
	}

	betterTiming.$dataStatus = document.querySelector('#__interceptedDataStatus');
	if (betterTiming.$dataStatus) {
		var betterTimingObserverStatus = new MutationObserver(function(mutations, observer) {
			if (betterTiming.$dataStatus.textContent !== "") {
				//console.log(JSON.parse(betterTiming.$data.textContent));
				updateData(betterTiming.$dataStatus.textContent);
			}
		});
		
		betterTimingObserverStatus.observe(betterTiming.$dataStatus, {
			attributes: true,
			characterData: true,
			childList: true,
			subtree: true,
			attributeOldValue: true,
			characterDataOldValue: true
		});
	}
}

function mapData() {
	var dataMaps = betterTiming.mapData.length
		, host = document.location.host
		, tempData = {}
		;
		
	//console.log(betterTiming.data);
	//console.log(dataMaps);

	for (var i=0; i < dataMaps; i++) {
		//console.log(betterTiming.mapData[i]);
		if (host === betterTiming.mapData[i].host) {
			//console.log('map ' + betterTiming.mapData[i].host + ' data:');

			var dataFields = Object.keys(betterTiming.data)
				, dataLength = dataFields.length
				, dataPoints = Object.keys(betterTiming.mapData[i].dataPoints)
				;

			for (var j=0; j < dataLength; j++) {
				// if dataField is in dataPoints, add it
				if (dataPoints.indexOf(dataFields[j]) !== -1) {
					var dataLabel = betterTiming.mapData[i].dataPoints[dataFields[j]]
						;

					if (dataLabel === "entries") {
						var teamData = betterTiming.data[dataFields[j]]
							, teamLength = teamData.length
							;

						if (teamLength > 0) {
							tempData["entries"] = [];
						}

						//console.log("iterate teams ", teamData, teamLength);
						for (var k=0; k < teamLength; k++) {
							var teamKeys = Object.keys(teamData[k])
								, teamKeyLength = teamKeys.length
								, teamTempData = {}
								, teamDataPoints = Object.keys(betterTiming.mapData[i].dataPoints["entries"])
								;

							//console.log(teamData[k], teamKeys, teamDataPoints);
							for (var l=0; l < teamKeyLength; l++) {
								//console.log(betterTiming.mapData[i].dataPoints["entries"][teamKeys[l]]);
								if (teamDataPoints.indexOf(teamKeys[l]) !== -1) {
									//console.log(betterTiming.mapData[i].dataPoints["entries"][teamKeys[l]], teamData[k][teamKeys[l]]);
									var fieldLabel = betterTiming.mapData[i].dataPoints["entries"][teamKeys[l]]
										, fieldValue = teamData[k][teamKeys[l]]
										;

									if (betterTiming.mapData[i].values["entries." + fieldLabel] !== undefined) {
										fieldValue = betterTiming.mapData[i].values["entries." + fieldLabel][fieldValue];
									}
									teamTempData[fieldLabel] = fieldValue;
								}
							}
							tempData["entries"].push(teamTempData);
							//console.log(tempData["entries"]);
						}
					} else {
						tempData[dataLabel] = betterTiming.data[dataFields[j]];
					}
				}
			}

			//console.log(tempData);
			//return false;

			betterTiming.data = {};

			var tempDataKeys = Object.keys(tempData)
				, tempDataLength = tempDataKeys.length
				;

			for (var i=0; i < tempDataLength; i++) {
				// properly nest data
				var keys = tempDataKeys[i].split('.')
					;

				if (keys.length > 1) {
					if (betterTiming.data[keys[0]] === undefined) {
						betterTiming.data[keys[0]] = {};
					}
					betterTiming.data[keys[0]][keys[1]] = tempData[tempDataKeys[i]];
				} else {
					betterTiming.data[keys[0]] = tempData[tempDataKeys[i]];
				}
			}
		}
	}

	//console.log(betterTiming.data);
}

function updateData(data){
	try {
		data = JSON.parse(data)
	} catch {
		data = data.replace('jsonpSessionInfo(','');
		data = data.replace('jsonpRaceResults(','');
		data = data.replace('});','}');
		if (data !== "") {
			data = JSON.parse(data)
		}
	}
	betterTiming.data = data;
	
	if (betterTiming.data !== "") {
		mapData();
		
		betterTiming.dataStatusLength = 0;
		if (betterTiming.data.params !== undefined) {
			betterTiming.dataStatusLength = betterTiming.data.params.length
		}
		
		betterTiming.dataCarsLength = 0;
		if (betterTiming.data.entries !== undefined) {
			if (typeof(betterTiming.data.entries) === "object") {
				betterTiming.dataCarsLength = Object.keys(betterTiming.data.entries).length
			} else {
				betterTiming.dataCarsLength = betterTiming.data.entries.length
			}
		}

		betterTiming.dataDriversLength = 0;
		if (betterTiming.data.driversResult !== undefined) {
			betterTiming.dataCarsLength = betterTiming.data.driversResult.length
		}

		//console.log(betterTiming.dataStatusLength, betterTiming.dataCarsLength, betterTiming.dataDriversLength);

		$('#__interceptedData').text('');

		if (betterTiming.isUpdate) {
			updateEnhancedView();
		} else {
			betterTiming.isUpdate = true;
			buildEnhancedView();
		}
	}
};

// build enhanced view
function buildEnhancedView(){
	//console.log('buildEnhancedView');
	enhance();
	
	// build standings
	betterTiming.$standingsTable = $('.enhanced-order tbody');
	betterTiming.sortTable = new Tablesort(document.querySelector('.enhanced-order'));
	
	// build status
	betterTiming.$statusTable = $('.enhanced-status tbody');
	populateRaceStatus();
	for (var i = 0; i < betterTiming.dataCarsLength; i++) {
		var $row = $('[data-template="car-row"]').clone()
			;
		populateTableData(betterTiming.data.entries[i], $row);
		$row.removeAttr('data-template').appendTo(betterTiming.$standingsTable);
	};
	
	checkOverallBest();
	calculatePitStrategy();

	// toggle row expanded on click
	betterTiming.$standingsTable.find('tr').on('click', function() {
		var $row = $(this);
		
		$row.toggleClass('expanded');
		if ($row.hasClass('expanded')) {
			populateDriverData($row);
		}
	})
};

// update enhanced view data
function updateEnhancedView(){
	clearInterval(betterTiming.countdownTimer);
	populateRaceStatus();
		
	for (var i = 0; i < betterTiming.dataCarsLength; i++) {
		if (betterTiming.data.entries[i] !== undefined) {
			var carId = betterTiming.data.entries[i]['id'];
			if (carId === undefined) {
				carId = betterTiming.data.entries[i]['category'] + betterTiming.data.entries[i]['number'];
			}
			//console.log(carId, betterTiming.data.entries[i]['id']);
			var	$row = betterTiming.$standingsTable.find('tr[data-ident="'+ carId +'"]');
			populateTableData(betterTiming.data.entries[i], $row);
		}
	};

	betterTiming.sortTable.refresh();
	checkOverallBest();
	calculatePitStrategy();
};

// highlight overall best lap/sector/speeds
function checkOverallBest() {
	var $pbs = betterTiming.$standingsTable.find('.pb')
		;

	for (var i = 0; i < $pbs.length; i++) {
		var $cell = $pbs.eq(i)
			;

		switch ($cell.attr('data-entry')) {
			case 'lastlap':
				var bestLap = moment(betterTiming.bestLap, ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					, rowBestLap = moment($cell.text(), ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					;

				if (rowBestLap < bestLap) {
					betterTiming.$standingsTable.find('.car-lap-times.ob').removeClass('ob');
					$cell.addClass('ob');
					betterTiming.bestLap = rowBestLap;
				}
			break;
			case 'lastSector1':
				var bestSector1 = moment(betterTiming.bestSector1, ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					, rowBestSector1 = moment($cell.text(), ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					;

				if (rowSector1 < bestSector1) {
					betterTiming.$standingsTable.find('[data-entry="currentSector1"]').removeClass('ob');
					$cell.addClass('ob');
					betterTiming.bestSector1 = rowSector1;
				}
			break;
			case 'lastSector2':
				var bestSector2 = moment(betterTiming.bestSector2, ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					, rowBestSector2 = moment($cell.text(), ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					;

				if (rowSector2 < bestSector2) {
					betterTiming.$standingsTable.find('[data-entry="currentSector2"]').removeClass('ob');
					$cell.addClass('ob');
					betterTiming.bestSector2 = rowSector2;
				}
			break;
			case 'lastSector3':
				var bestSector3 = moment(betterTiming.bestSector3, ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					, rowBestSector3 = moment($cell.text(), ['hh:mm:ss.SSS' ,'mm:ss.SSS', 'ss.SSS']).format('mm:ss.SSS')
					;

				if (rowSector3 < bestSector3) {
					betterTiming.$standingsTable.find('[data-entry="currentSector3"]').removeClass('ob');
					$cell.addClass('ob');
					betterTiming.bestSector3 = rowSector2;
				}
			break;
			default:
				//console.log("No valid cell.");
		}
	}

	var $rows = betterTiming.$standingsTable.find('tr')
		;

	for (var i = 1; i < $rows.length; i++) {
		var $row = $rows.eq(i)
			, rowSpeed = parseFloat($row.find('[data-entry="speed"]').text(), 10)
			;

		if (rowSpeed > betterTiming.bestSpeed) {
			betterTiming.$standingsTable.find('[data-entry="speed"].ob').removeClass('ob');
			$row.find('[data-entry="speed"]').addClass('ob');
			betterTiming.bestSpeed = rowSpeed;
		}
	}
};

function populateRaceStatus() {
	StatusData = betterTiming.data.params;
	//console.log(StatusData);
	betterTiming.$statusTable.find('[data-status]').each(function() {
		var field = $(this).attr('data-status')
			, $this = $(this)
			;
			
		//console.log(field, $this);

		if (field !== undefined && StatusData !== undefined) {
			$this.text(StatusData[field]);
			
			switch (field) {
				case 'racestate':
					$this[0].classList = $this.text().toLowerCase() + '_flag status'; //.text('');
				break;
				case 'weather':
					if (betterTiming.weather[StatusData[field]]) {
						$this.text(betterTiming.weather[StatusData[field]] + ', ' + StatusData['airTemp'] + '°/' + StatusData['trackTemp'] + '°');
					}
				break;
				case 'elapsed':
				case 'remaining':
					// fake countdown + estimated laps left
					var remainingTime = StatusData[[field]];
					if (remainingTime !== undefined) {
						betterTiming.seconds = remainingTime.toString();
						if (typeof(remainingTime) === "string" && remainingTime.split(':').length > 1) {
							betterTiming.seconds = convertHMStoSeconds(remainingTime);
						}
						betterTiming.seconds = parseInt(betterTiming.seconds, 10);
						betterTiming.$timer = $(this);
							
						betterTiming.countdown = function() {
							if (betterTiming.seconds > 0) {						
								betterTiming.$timer.text(convertSecondsToHMS(betterTiming.seconds));
								betterTiming.seconds--;
								
								var $firstPlace = betterTiming.$standingsTable.find('tr').eq(1);
								
								if ($firstPlace.length > 0) {
									var lapsCompleted = parseInt($firstPlace.find('[data-entry="lap"]').text(), 10)
										, elapsed = StatusData['elasped']
										;

									if (elapsed !== undefined) {
										if (elapsed.split(':').length > 1) {
											elapsed = convertHMStoSeconds(elapsed);
										} else {
											elapsed = elapsed;
										}
									}
									betterTiming.lapsRemaining = Math.floor(betterTiming.seconds / (elapsed/lapsCompleted)) + 1
									
									if (betterTiming.lapsRemaining > 0 && betterTiming.lapsRemaining < 600) {
										betterTiming.$timer.text(betterTiming.$timer.text() + ' (~ ' + betterTiming.lapsRemaining + ' laps)');
									}
								}
							} else {
								betterTiming.$timer.text('Finished');
								clearInterval(betterTiming.countdownTimer);
							}
						}
						betterTiming.countdown();
						try {
							if (StatusData['racestate'].toLowerCase() != "chk" && StatusData['racestate'].toLowerCase() != "off") {
								betterTiming.countdownTimer = setInterval(betterTiming.countdown, 1000);
							}
						} catch {
							// update didn't contain this data
						}
					}
				break;
				default:
					//console.log(field + ' not a valid field.');
			}
		}
	});
}

function convertSecondsToHMS(seconds) {
	var hours = Math.floor(seconds / 3600)
		, minutes = Math.floor(((seconds / 3600 ) % 1) * 60)
		;
		
	var seconds = seconds % 60;
	
	if (hours < 10) {
		hours = "0" + hours;
	}					
	if (minutes < 10) {
		minutes = "0" + minutes;
	}
	if (seconds < 10) {
		seconds = "0" + seconds;
	}
	
	return (hours + ':' + minutes + ':' + seconds);
}

function convertHMStoSeconds(time) {
	var groups = time.split(':')
		, hours = parseInt(groups[0], 10)
		, minutes = parseInt(groups[1], 10)
		, seconds = parseInt(groups[2], 10)
		;

	return (seconds + minutes * 60 + hours * 3600)
}

function populateTableData(carData, $row) {
	if (carData !== undefined && $row) {
		var carClass = carData['category']
			, currentSector = carData['sector']
			;

		if (carClass === "") {
			$row.hide();
		} else {
			$row.show();
		}

		if (currentSector === undefined) {
			$('[data-sector-header], [data-sector]').hide();
		} else {
			$('[data-sector-header], [data-sector]').show();
		}

		if ($row.attr('data-ident') === undefined) {
			$row.attr('data-ident', carData['id']);
			if (carData['id'] === undefined) {
				$row.attr('data-ident', carData['category'] + carData['number']);
			}
		}

		if (carData['speed'] === undefined) {
			$('[data-speed-header], [data-speed]').hide();
		} else {
			$('[data-speed-header], [data-speed]').show();
		}

		$row.addClass(carClass);
		$row.find('.pb').removeClass('pb');
		$row.find('.ob').removeClass('ob');
		
		$row.find('[data-entry]').each(function() {
			var field = $(this).attr('data-entry')
				, $this = $(this)
				;
			$this.text(carData[field]);
		
			switch (field) {
				case 'number':
				case 'categoryPosition':
				case 'team':
				case 'car':
				case 'tyre':
					if ($this.text() === "") {
						$this.hide();
					} else {
						$this.show();
					}
					$this.addClass(carClass);
				break;
				case 'state':
					$this[0].classList = 'car-state state-' + carData[field].toLowerCase();
					if (carData[field].toLowerCase() === "stop") {
						$row.addClass('car-state-stop');
					} else {
						$row.removeClass('car-state-stop');
					}
				break;
				case 'laptime':
					if ( carData[field] === carData['bestlap'] ) {
						$this.addClass('pb');
					};
					if ($this.text() === "") {
						$this.html('&nbsp;');
					}
				break;
				case 'gapPrev':
					$this.closest('td').removeClass('popcorn-time');
					var gapPrevString = carData[field];
					if ( parseFloat(gapPrevString, 10) < 1.5 && gapPrevString.indexOf(' ') === -1 && gapPrevString.indexOf(':') === -1) {
						$this.closest('td').addClass('popcorn-time');
					}
					break;
				case 'currentSector1':
					if ( carData[field] == carData['bestSector1'] ) {
						$this.addClass('pb');
					};
					if ($this.text() === "") {
						$this.html('&nbsp;');
					}
				break;
				case 'currentSector2':
					if ( carData[field] == carData['bestSector2'] ) {
						$this.addClass('pb');
					};
					if ($this.text() === "") {
						$this.html('&nbsp;');
					}
				break;
				case 'currentSector3':
					if ( carData[field] == carData['bestSector3'] ) {
						$this.addClass('pb');
					};
					if ($this.text() === "") {
						$this.html('&nbsp;');
					}
				break;
				default:
					//console.log(field + " is not a valid field.");
			}
		});
		
		// sector progress indicator
		$row.find('.bar').css('width', '0');
		$row.find('[data-sector]').removeClass('recent').each(function() {
			if ($(this).attr('data-sector') == currentSector) {
				var $bar = $(this).find('.bar');
				$bar.text((parseFloat(carData['position']['percent'], 10) * 100));
				$bar.css('width', (parseFloat(carData['position']['percent'], 10) * 100) + '%');
				return;
			}
		});
		
		populateDriverData($row);
	}
}

function populateDriverData($row) {
	if ($row.hasClass('expanded')) {
		var $driverDetail = $row.find('.driver-detail')
			, $driverDetailPopup = $driverDetail.find('.driver-detail-popup')
			, driverId = $driverDetail.find('[data-entry="driver_id"]').text()
			;
			
		for( var i=0; i < betterTiming.dataDriversLength; i++) {
			if (betterTiming.data.driversResult[i]['driverID'] == driverId) {
				driverData = betterTiming.data.driversResult[i];
				
				$driverDetailPopup.html('<table><thead>' +
					'<tr><th>Laps</th><th>Best Lap</th><th>Best Lap #</th><th>Last Lap Diff</th><th>Driving Time</th></tr></thead>' +
					'<tbody><tr>' +
						'<td>' + driverData['laps'] + '</td>' +
						'<td>' + driverData['bestLap'] + '</td>' +
						'<td>' + driverData['bestLapNumber'] + '</td>' +
						'<td>' + driverData['lastLapDiff'] + '</td>' +
						'<td>' + convertSecondsToHMS(driverData['drivingTime']) + '</td>' +
					'</tr></tbody></table>'
				);
				break;
			}
		}
	}
}

function calculatePitStrategy() {
	var $pitstops = betterTiming.$standingsTable.find('[data-entry="pitstop"]')
	;

  for (var i = 1; i < $pitstops.length; i++) {
		// estimate next stops for each car
		var $this = $pitstops.eq(i)
			, $row = $this.closest('tr')
			, $cell = $this.closest('.car-pitstops')
			, $estimate = $cell.find('[data-calc="pit-estimate"]')
			, $remaining = $cell.find('[data-calc="pit-remaining"]')
			, pitstops = parseInt($this.text(), 10)
			;
			
		if (pitstops > 0 && betterTiming.lapsRemaining < 600) {
			var laps = parseInt($row.find('[data-entry="lap"]').text(), 10)
			, averageStintLength = laps / pitstops
			//, lapsUntilStop = Math.floor((Math.ceil( laps / averageStintLength) * averageStintLength) - laps)
			, remainingStops = Math.ceil(betterTiming.lapsRemaining / averageStintLength)
			, carState = $row.find('.car-state').text().toLowerCase()
			;
			
			if (remainingStops === NaN) {
				$remaining.html("?");
			} else if (remainingStops <= 1 ) {
				$remaining.text('1 Left?');
			} else if (remainingStops >= 2) {
				$remaining.text(remainingStops + " Left?");
			} else {
				$remaining.text("!");
			}

			//$cell.removeClass('imminent');
			// if (pitstops > 2) {
			// 	if (lapsUntilStop === NaN) {
			// 		$estimate.html("?");
			// 	} else if (lapsUntilStop < 2 && carState == 'run' ) {
			// 		$estimate.text('Next: Now?');
			// 		$cell.addClass('imminent');
			// 	} else if (lapsUntilStop >= 2) {
			// 		$estimate.text('Next: ' + lapsUntilStop + 'Laps?');
			// 	} else {
			// 		$estimate.text("!");
			// 	}
			// } else {
			// 	$estimate.html("?");
			// };
		}
	}
}

// observe ajax requests and add response to body
function interceptData() {
	var xhrOverrideScript = document.createElement('script');
	xhrOverrideScript.type = 'text/javascript';
	xhrOverrideScript.innerHTML = `
	(function() {
		var XHR = XMLHttpRequest.prototype;
		var send = XHR.send;
		var open = XHR.open;
		XHR.open = function(method, url) {
			this.url = url; // the request url
			return open.apply(this, arguments);
		}
		XHR.send = function() {
			this.addEventListener('load', function() {
				if (
					this.url.includes('data.json') || 
					this.url.includes('1__data.json') || 
					this.url.includes('2__data.json') || 
					this.url.includes('3__data.json') || 
					this.url.includes('4__data.json') || 
					this.url.includes('RaceData.json') || 
					this.url.includes('RaceData-2.json') || 
					this.url.includes('https://cors-anywhere.herokuapp.com/https://storage.googleapis.com/fiawec-prod/assets/live/WEC/__data.json') ||
					this.url.includes('https://storage.googleapis.com/fiawec-prod/assets/live/WEC/__data.json') ||
					this.url.includes('https://cors-anywhere.herokuapp.com/https://scoring.imsa.com/scoring_data/RaceResults_JSONP.json?callback=jsonpRaceResults') ||
					this.url.includes('https://scoring.imsa.com/scoring_data/RaceResults_JSONP.json?callback=jsonpRaceResults') //||
					//this.url.includes('https://cors-anywhere.herokuapp.com/https://scoring.imsa.com/scoring_data/SessionInfo_JSONP.json?callback=jsonpSessionInfo') ||
					//this.url.includes('https://scoring.imsa.com/scoring_data/SessionInfo_JSONP.json?callback=jsonpSessionInfo')
				) {
					var responseContainingEle = document.getElementById('__interceptedData');
					
					if (responseContainingEle) {
						responseContainingEle.innerText = this.response;
					} else {
						var dataDOMElement = document.createElement('div');
						dataDOMElement.id = '__interceptedData';
						dataDOMElement.innerText = this.response;
						dataDOMElement.style.height = 0;
						dataDOMElement.style.overflow = 'hidden';
						document.body.appendChild(dataDOMElement);
					}
				}
				if (
					this.url.includes('SessionInfo.json') ||
					this.url.includes('SessionInfo-2.json') ||
					this.url.includes('https://cors-anywhere.herokuapp.com/https://scoring.imsa.com/scoring_data/SessionInfo_JSONP.json?callback=jsonpSessionInfo') ||
					this.url.includes('https://scoring.imsa.com/scoring_data/SessionInfo_JSONP.json?callback=jsonpSessionInfo')
				) {
					var responseContainingEleStatus = document.getElementById('__interceptedDataStatus');
					
					if (responseContainingEleStatus) {
						responseContainingEleStatus.innerText = this.response;
					} else {
						var dataDOMElementStatus = document.createElement('div');
						dataDOMElementStatus.id = '__interceptedDataStatus';
						dataDOMElementStatus.innerText = this.response;
						dataDOMElementStatus.style.height = 0;
						dataDOMElementStatus.style.overflow = 'hidden';
						document.body.appendChild(dataDOMElementStatus);
					}
				}
			});
			return send.apply(this, arguments);
		};
	})();
	`
 	document.head.prepend(xhrOverrideScript);
}

// once body and head are available, inject script
function checkForDOM() {
	if (document.body && document.head) {
		interceptData();
	} else {
		requestIdleCallback(checkForDOM);
	}
}
requestIdleCallback(checkForDOM);

// watch for intercepted data to be available
function scrapeData() {
	var responseContainingEle = document.getElementById('__interceptedData');
	if (responseContainingEle) {
		updateData(responseContainingEle.innerHTML);
	} else {
		requestIdleCallback(scrapeData);
	}
}
requestIdleCallback(scrapeData);
